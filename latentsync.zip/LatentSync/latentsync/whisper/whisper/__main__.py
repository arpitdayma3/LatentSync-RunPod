from .transcribe import cli


cli()
